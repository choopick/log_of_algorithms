# [START]
class MyMatrix:
    def getMatrix(N):
        if (type(N) != int()) or (N <= 0) or (N%2 == 0):
            return -1
        else:
            return 0

myt = MyMatrix()
myt.num = 3
print(myt.getMatrix())

# [END]

print("==> CLEAR!") # Don't remove this line